/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Zap, Shield, HeartHandshake, PenTool, BookOpen, CheckCircle, Circle, Award, TrendingUp } from "lucide-react";
import { StreakBadge, HabitTask, WeeklyActivity } from "../types";

interface StreaksViewProps {
  streakCount: number;
  badges: StreakBadge[];
  habits: HabitTask[];
  weeklyActivity: WeeklyActivity[];
  onToggleHabit: (id: string) => void;
}

export default function StreaksView({
  streakCount,
  badges,
  habits,
  weeklyActivity,
  onToggleHabit,
}: StreaksViewProps) {
  
  // Icon mapper helper
  const getBadgeIcon = (iconName: string, unlocked: boolean) => {
    const iconClass = `w-5 h-5 ${unlocked ? "text-accent-gold" : "text-zinc-600"}`;
    switch (iconName) {
      case "Zap":
        return <Zap className={iconClass} />;
      case "Shield":
        return <Shield className={iconClass} />;
      case "HeartHandshake":
        return <HeartHandshake className={iconClass} />;
      case "PenTool":
        return <PenTool className={iconClass} />;
      default:
        return <BookOpen className={iconClass} />;
    }
  };

  const completedHabitsCount = habits.filter((h) => h.completed).length;
  const habitPercentage = Math.round((completedHabitsCount / habits.length) * 100);

  return (
    <div className="flex-1 flex flex-col gap-6 pt-4 text-warm-beige select-none">
      
      {/* Header title */}
      <div>
        <span className="text-[10px] uppercase font-sans tracking-widest text-[#D4A75D] font-bold bg-[#D4A75D]/10 px-2.5 py-1 rounded-full border border-accent-gold/20">
          My Journey
        </span>
        <h2 className="text-2xl font-serif font-bold text-[#F5F1E8] mt-2 font-display">Spiritual Milestones</h2>
      </div>

      {/* Main active streak display with golden glow badge */}
      <div className="rounded-3xl bg-gradient-to-br from-[#1B1F27] to-[#0F1115] p-6 border border-[#D4A75D]/25 relative overflow-hidden cinematic-glow flex items-center justify-between">
        <div className="absolute top-0 right-0 w-32 h-32 bg-[#D4A75D]/5 rounded-full filter blur-2xl pointer-events-none" />
        
        <div className="z-10">
          <span className="text-[10px] font-sans text-zinc-400 font-semibold uppercase tracking-wider block">CURRENT STEADY STREAK</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-4xl font-serif font-bold text-[#F5F1E8]">{streakCount}</span>
            <span className="text-sm text-accent-gold font-cinzel font-bold">Days Active</span>
          </div>
          <p className="text-[11px] text-zinc-400 mt-2 max-w-[180px] leading-relaxed">
            Consistently seeking peace daily. You are in the top 3% of mindful partners.
          </p>
        </div>

        {/* Big circular golden ring with glow */}
        <div className="relative w-24 h-24 rounded-full border-4 border-dashed border-[#D4A75D]/30 flex items-center justify-center gold-glow shrink-0 bg-[#0F1115]/50">
          <Award className="w-10 h-10 text-accent-gold animate-bounce" />
          <div className="absolute inset-0.5 rounded-full border-2 border-[#D4A75D] animate-ping opacity-15" />
        </div>
      </div>

      {/* Analytical charts - Weekly progress minutes tracking (Headspace style) */}
      <div className="rounded-3xl glassmorphism p-5 border border-white/5 flex flex-col gap-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 font-semibold text-xs tracking-wider uppercase text-zinc-300">
            <TrendingUp className="w-4 h-4 text-[#D4A75D]" />
            <span>Weekly sanctuary minutes</span>
          </div>
          <span className="text-[10px] text-zinc-500 font-mono">2026-05</span>
        </div>

        {/* Simple elegant responsive flex bar graph using exact pixel variables */}
        <div className="flex items-end justify-between h-20 pt-2 px-1">
          {weeklyActivity.map((dayData) => {
            const maxActivityMinutes = 50; 
            const barHeightPercentage = Math.min((dayData.minutes / maxActivityMinutes) * 100, 100);

            return (
              <div key={dayData.day} className="flex flex-col items-center gap-1.5 flex-1">
                <span className="text-[9px] font-mono text-zinc-500">{dayData.minutes}m</span>
                <div className="w-6 bg-[#16191E] rounded-md h-12 relative overflow-hidden border border-white/5">
                  <div
                    style={{ height: `${barHeightPercentage}%` }}
                    className={`absolute bottom-0 left-0 right-0 rounded-t-sm transition-all duration-500 ${
                      dayData.completed
                        ? "bg-gradient-to-t from-amber-600/60 to-accent-gold"
                        : "bg-zinc-800"
                    }`}
                  />
                </div>
                <span className={`text-[9px] font-sans font-bold ${dayData.completed ? "text-[#F5F1E8]" : "text-zinc-600"}`}>
                  {dayData.day}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Daily Spiritual Habit tracker checklist widget */}
      <div className="rounded-3xl glassmorphism p-5 border border-white/5 flex flex-col gap-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-xs font-semibold tracking-wider font-sans uppercase text-zinc-300">Daily Sanctuary Habits</h3>
            <span className="text-[10px] text-zinc-500 font-sans mt-0.5 block">{completedHabitsCount} of {habits.length} routines completed</span>
          </div>
          <span className="text-xs font-bold text-accent-gold bg-[#D4A75D]/10 px-2.5 py-0.5 rounded-full border border-[#D4A75D]/20">
            {habitPercentage}%
          </span>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-[#16191E] h-1.5 rounded-full overflow-hidden border border-white/5">
          <div
            style={{ width: `${habitPercentage}%` }}
            className="h-full bg-gradient-to-r from-amber-600 to-[#D4A75D] transition-all duration-300 shadow-[0_0_8px_rgba(212,167,93,0.3)]"
          />
        </div>

        {/* Habit lines checklist */}
        <div className="space-y-2.5 pt-2">
          {habits.map((h) => (
            <button
              key={h.id}
              onClick={() => onToggleHabit(h.id)}
              className="w-full flex items-center justify-between p-3.5 rounded-2xl bg-[#1B1F27]/60 border border-white/5 hover:border-zinc-800/80 transition text-left cursor-pointer select-none group"
            >
              <div className="flex items-center gap-3">
                {h.completed ? (
                  <CheckCircle className="w-4 h-4 text-accent-gold fill-current" />
                ) : (
                  <Circle className="w-4 h-4 text-zinc-600 group-hover:text-zinc-400 group-hover:scale-110 transition" />
                )}
                <span className={`text-xs font-sans transition-all font-medium ${h.completed ? "line-through text-zinc-500" : "text-zinc-200"}`}>
                  {h.title}
                </span>
              </div>
              <span className="text-[9px] font-mono text-zinc-500 bg-zinc-950/40 px-2 py-0.5 rounded-full border border-white/5 font-semibold">
                {h.timeOfDay}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Streak Achievements Badges shelf */}
      <div className="flex flex-col gap-3">
        <h3 className="text-xs font-semibold tracking-wider font-sans uppercase text-zinc-400 px-1">Achievements Earned</h3>
        <div className="grid grid-cols-2 gap-3.5 pb-4">
          {badges.map((badge) => (
            <div
              key={badge.id}
              className={`p-4 rounded-2xl border transition relative overflow-hidden group ${
                badge.unlocked
                  ? "bg-gradient-to-tr from-[#1E222A] to-[#16191E] border-[#D4A75D]/25"
                  : "bg-[#1E222A]/20 border-white/5 opacity-50"
              }`}
            >
              {badge.unlocked && (
                <div className="absolute -top-6 -right-6 w-12 h-12 bg-amber-500/10 rounded-full blur-md" />
              )}
              <div className="flex justify-between items-start mb-3">
                <div className={`p-2.5 rounded-xl border ${
                  badge.unlocked
                    ? "bg-[#D4A75D]/10 border-[#D4A75D]/30"
                    : "bg-zinc-900 border-white/5"
                }`}>
                  {getBadgeIcon(badge.iconName, badge.unlocked)}
                </div>
                {badge.unlocked && (
                  <span className="text-[8px] font-mono text-accent-gold bg-[#D4A75D]/10 px-1.5 py-0.5 rounded border border-[#D4A75D]/10 font-bold uppercase">
                    Unlocked
                  </span>
                )}
              </div>
              <h4 className="text-xs font-bold text-zinc-200 group-hover:text-accent-gold transition-colors">{badge.title}</h4>
              <p className="text-[10px] text-zinc-400 mt-1 leading-normal font-sans">{badge.description}</p>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
