/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from "react";
import { Send, Sparkles, Book, Heart, BookOpen, AlertCircle, RefreshCw } from "lucide-react";
import { ChatMessage } from "../types";
import { motion, AnimatePresence } from "motion/react";

interface ChatViewProps {
  chatHistory: ChatMessage[];
  onSendMessage: (text: string) => void;
  isLoading: boolean;
}

export default function ChatView({ chatHistory, onSendMessage, isLoading }: ChatViewProps) {
  const [inputText, setInputText] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const suggestedPrompts = [
    { text: "Prayer for overwhelming anxiety", icon: Heart, label: "Comfort" },
    { text: "Explain Psalm 23:4 contextually", icon: Book, label: "Scripture" },
    { text: "The spiritual meaning of forgiveness", icon: BookOpen, label: "Theology" },
  ];

  // Auto-scroll on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatHistory, isLoading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || isLoading) return;
    onSendMessage(inputText.trim());
    setInputText("");
  };

  return (
    <div className="flex-1 flex flex-col h-full gap-4 pt-4 text-warm-beige select-none">
      
      {/* Search/Companion Avatar Header with subtle animation */}
      <div className="flex items-center gap-3.5 pb-2.5 border-b border-zinc-800/60">
        <div className="relative">
          <div className="absolute inset-0 bg-gradient-to-tr from-[#D4A75D] to-amber-200 rounded-full blur-sm opacity-50 animate-pulse" />
          <div className="w-11 h-11 rounded-full bg-[#1B1F27] border-2 border-[#D4A75D] flex items-center justify-center font-cinzel text-accent-gold font-bold text-sm relative z-10">
            FFΩ
          </div>
          <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 rounded-full border-2 border-[#0F1115] z-20" />
        </div>
        <div>
          <div className="flex items-center gap-1.5">
            <h3 className="font-serif text-base font-semibold">Scribe Spiritual AI</h3>
            <Sparkles className="w-4 h-4 text-accent-gold animate-bounce" />
          </div>
          <p className="text-[10px] text-zinc-400">Compassionate scriptural wisdom & prayers</p>
        </div>
      </div>

      {/* Suggested prompting list if database is quiet */}
      {chatHistory.length <= 1 && (
        <div className="flex flex-col gap-3 py-1 bg-gradient-to-r from-[#1B1F27]/30 to-[#1B1F27]/10 p-3 rounded-2xl border border-white/5 shrink-0">
          <p className="text-[10px] font-semibold text-accent-gold uppercase tracking-widest font-sans px-1">Suggested Seekings</p>
          <div className="flex flex-col gap-2">
            {suggestedPrompts.map((item, idx) => {
              const Icon = item.icon;
              return (
                <button
                  key={idx}
                  onClick={() => onSendMessage(item.text)}
                  className="flex items-center justify-between text-left p-3 rounded-xl bg-[#1B1F27]/70 border border-white/5 hover:border-[#D4A75D]/40 hover:bg-[#1B1F27] transition shrink-0 cursor-pointer group"
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className="w-4 h-4 text-[#D4A75D] group-hover:scale-110 transition" />
                    <span className="text-xs text-zinc-200 font-medium">{item.text}</span>
                  </div>
                  <span className="text-[9px] font-mono font-bold text-[#D4A75D]/70 bg-[#D4A75D]/5 px-2 py-0.5 rounded-full border border-[#D4A75D]/10">
                    {item.label}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Chat Messages Frame Viewport */}
      <div className="flex-1 overflow-y-auto px-1 space-y-4 min-h-[300px] max-h-[460px] pb-4">
        {chatHistory.map((msg) => {
          const isUser = msg.role === "user";
          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isUser ? "items-end" : "items-start"}`}
            >
              <div
                className={`max-w-[85%] rounded-2xl p-4.5 text-xs leading-relaxed border ${
                  isUser
                    ? "bg-[#D4A75D] text-[#0F1115] border-[#D4A75D] font-medium rounded-tr-none shadow-[0_5px_15px_rgba(212,167,93,0.15)]"
                    : "bg-[#1B1F27] text-zinc-300 border-white/5 rounded-tl-none shadow-md"
                }`}
              >
                {!isUser ? (
                  <div className="whitespace-pre-line leading-relaxed font-sans">{msg.content}</div>
                ) : (
                  <div className="font-sans font-medium">{msg.content}</div>
                )}
              </div>
              <span className="text-[8px] text-zinc-500 font-mono mt-1 px-1">
                {msg.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
              </span>
            </div>
          );
        })}

        {/* Loading / Typing Animation */}
        {isLoading && (
          <div className="flex flex-col items-start">
            <div className="rounded-2xl rounded-tl-none p-4 bg-[#1B1F27] border border-white/5 shadow-md flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-[#D4A75D] rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
              <span className="w-1.5 h-1.5 bg-[#D4A75D] rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
              <span className="w-1.5 h-1.5 bg-[#D4A75D] rounded-full animate-bounce" style={{ animationDelay: "300ms text-color-space" }} />
              <span className="text-[10px] text-zinc-400 font-mono ml-2">FaithFlow reflecting...</span>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Form Bar */}
      <form onSubmit={handleSubmit} className="flex gap-2 relative mt-auto pt-2 bg-[#0F1115] z-10 shrink-0">
        <input
          type="text"
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          placeholder="Ask a question or share a heavy concern..."
          className="flex-1 rounded-2xl bg-[#1B1F27] border border-white/10 px-4 py-3 pb-3 text-xs text-warm-beige focus:outline-none focus:border-[#D4A75D] placeholder-zinc-500 font-sans tracking-wide"
          disabled={isLoading}
        />
        <button
          type="submit"
          className="w-11 h-11 rounded-2xl bg-[#D4A75D] hover:bg-amber-500 hover:scale-105 active:scale-95 transition text-[#0F1115] flex items-center justify-center shrink-0 cursor-pointer disabled:opacity-50 disabled:scale-100 disabled:pointer-events-none"
          disabled={!inputText.trim() || isLoading}
        >
          <Send className="w-4 h-4 text-[#0F1115] fill-current" />
        </button>
      </form>
    </div>
  );
}
