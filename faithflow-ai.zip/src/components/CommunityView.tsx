/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { MessageSquare, Heart, Plus, Shield, Send, Check, Search, Calendar, HeartHandshake } from "lucide-react";
import { PrayerPost } from "../types";

interface CommunityViewProps {
  posts: PrayerPost[];
  onAddPost: (content: string, isAnonymous: boolean, category: any) => void;
  onReactPost: (id: string, type: "pray" | "heart") => void;
}

export default function CommunityView({ posts, onAddPost, onReactPost }: CommunityViewProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [content, setContent] = useState("");
  const [isAnonymous, setIsAnonymous] = useState(true);
  const [selectedCategory, setSelectedCategory] = useState<PrayerPost["category"]>("Comfort");
  const [filterCategory, setFilterCategory] = useState<string>("All");

  const categories: PrayerPost["category"][] = [
    "Praise",
    "Healing",
    "Comfort",
    "Anxiety",
    "Strength",
    "Guidance",
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content.trim()) return;
    onAddPost(content.trim(), isAnonymous, selectedCategory);
    setContent("");
    setIsAdding(false);
  };

  const filteredPosts = filterCategory === "All"
    ? posts
    : posts.filter((p) => p.category === filterCategory);

  return (
    <div className="flex-1 flex flex-col gap-6 pt-4 text-warm-beige select-none">
      
      {/* Wall Header */}
      <div className="flex items-center justify-between">
        <div>
          <span className="text-[10px] uppercase font-sans tracking-widest text-[#D4A75D] font-bold bg-[#D4A75D]/10 px-2.5 py-1 rounded-full border border-accent-gold/20">
            Prayer Wall
          </span>
          <h2 className="text-2xl font-serif font-bold text-[#F5F1E8] mt-2">Shared Sanctuary</h2>
        </div>
        {!isAdding && (
          <button
            onClick={() => setIsAdding(true)}
            className="w-10 h-10 rounded-full bg-[#D4A75D] hover:bg-amber-400 text-[#0F1115] flex items-center justify-center cursor-pointer hover:scale-105 active:scale-95 transition shadow-lg shadow-amber-500/10"
          >
            <Plus className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Write Prayer request form */}
      {isAdding && (
        <form onSubmit={handleSubmit} className="rounded-3xl glassmorphism p-5 flex flex-col gap-4 border border-[#D4A75D]/20 cinematic-glow relative">
          <div className="absolute top-0 right-14 w-20 h-20 bg-amber-500/5 rounded-full filter blur-xl" />
          
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-sans text-zinc-400 flex items-center gap-1 uppercase font-semibold">
              <Shield className="w-3.5 h-3.5 text-[#D4A75D]" />
              Secure Anonymous Prayer
            </span>
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="text-xs text-zinc-400 hover:text-zinc-200 cursor-pointer uppercase"
            >
              Cancel
            </button>
          </div>

          {/* Select category */}
          <div className="flex flex-col gap-1.5">
            <p className="text-[10px] uppercase tracking-wider text-zinc-400 font-semibold">Prayer Intent</p>
            <div className="flex flex-wrap gap-1.5">
              {categories.map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setSelectedCategory(cat)}
                  className={`text-[10px] px-2.5 py-1 rounded-full border transition cursor-pointer select-none ${
                    selectedCategory === cat
                      ? "bg-[#D4A75D] text-[#0F1115] border-[#D4A75D] font-bold"
                      : "bg-[#1B1F27]/60 text-zinc-400 border-white/5 hover:text-zinc-200"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="Share what is heavy on your soul. Be comforted knowing this community surrounds you in silent prayers..."
            rows={4}
            required
            className="w-full text-xs bg-[#1B1F27] border border-white/10 rounded-2xl p-4 focus:outline-none focus:border-[#D4A75D] placeholder-zinc-500 font-sans leading-relaxed text-warm-beige"
          />

          <div className="flex items-center justify-between pt-1">
            <label className="flex items-center gap-2 text-xs text-zinc-300 cursor-pointer">
              <input
                type="checkbox"
                checked={isAnonymous}
                onChange={(e) => setIsAnonymous(e.target.checked)}
                className="w-3.5 h-3.5 rounded border-white/10 bg-[#1B1F27] text-[#D4A75D] focus:ring-0 cursor-pointer"
              />
              <span>Post Anonymously</span>
            </label>

            <button
              type="submit"
              className="py-2.5 px-5 bg-[#D4A75D] hover:bg-amber-400 text-[#0F1115] rounded-xl font-bold text-xs uppercase tracking-widest transition cursor-pointer flex items-center gap-2 shadow-md shadow-[#D4A75D]/10"
            >
              <Send className="w-3 h-3 fill-current" />
              Lift Up
            </button>
          </div>
        </form>
      )}

      {/* Category filters */}
      <div className="flex flex-col gap-2.5 bg-[#1B1F27]/25 p-3 rounded-2xl border border-white/5 shrink-0">
        <p className="text-[10px] uppercase font-sans tracking-wide text-zinc-400 font-semibold px-0.5">Filter Intentions</p>
        <div className="flex gap-2 overflow-x-auto pb-1.5 scrollbar-none">
          {["All", ...categories].map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`text-[10px] px-3.5 py-1.5 rounded-full border transition cursor-pointer whitespace-nowrap shrink-0 font-medium ${
                filterCategory === cat
                  ? "bg-[#D4A75D] text-[#0F1115] border-[#D4A75D] font-bold"
                  : "bg-[#1B1F27]/60 text-zinc-400 border-white/5 hover:text-zinc-200"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Prayer Feed wall items */}
      <div className="flex flex-col gap-4">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-semibold text-zinc-400 font-sans uppercase">Intention Feed ({filteredPosts.length})</span>
          <span className="text-[10px] text-zinc-500 font-mono">Real-time updates</span>
        </div>

        <div className="space-y-4 max-h-[460px] overflow-y-auto pr-1 pb-4">
          {filteredPosts.map((post) => (
            <div
              key={post.id}
              className="rounded-2xl glassmorphism p-5 border border-white/5 hover:border-zinc-800/80 transition flex flex-col gap-3 relative"
            >
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <div className="w-7 h-7 rounded-full bg-[#1B1F27] border border-white/5 flex items-center justify-center font-serif text-[10px] text-[#D4A75D] font-bold uppercase select-none">
                    {post.isAnonymous ? "🔒" : post.author.substring(0, 2)}
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-zinc-200 leading-none">
                      {post.isAnonymous ? "Anonymous Sanctuary Seeker" : post.author}
                    </h4>
                    <span className="text-[8px] text-zinc-500 font-mono">{post.timestamp}</span>
                  </div>
                </div>

                <span className="text-[9px] font-mono font-bold text-[#D4A75D] bg-[#D4A75D]/10 px-2.5 py-0.5 rounded-full border border-accent-gold/20">
                  {post.category}
                </span>
              </div>

              <p className="text-xs text-zinc-300 leading-relaxed font-sans whitespace-pre-line bg-zinc-950/20 p-3 rounded-xl border border-white/5">
                {post.content}
              </p>

              {/* Interaction row (Pray reactions and Heart reactions) */}
              <div className="flex items-center justify-between pt-2 border-t border-zinc-800/40">
                <div className="flex items-center gap-3">
                  
                  {/* Pray Reaction Button */}
                  <button
                    onClick={() => onReactPost(post.id, "pray")}
                    className={`flex items-center gap-2 py-1.5 px-3 rounded-lg border text-[10px] font-sans font-semibold transition cursor-pointer select-none ${
                      post.userPrayed
                        ? "bg-[#D4A75D]/15 text-[#F5F1E8] border-[#D4A75D]/50"
                        : "bg-[#1B1F27]/60 border-white/5 text-zinc-400 hover:text-zinc-200"
                    }`}
                  >
                    <HeartHandshake className={`w-3.5 h-3.5 ${post.userPrayed ? "text-accent-gold animate-bounce" : ""}`} />
                    <span>{post.prayersCount} Interceded</span>
                  </button>

                  {/* Heart Reaction Button */}
                  <button
                    onClick={() => onReactPost(post.id, "heart")}
                    className={`flex items-center gap-2 py-1.5 px-3 rounded-lg border text-[10px] font-sans font-semibold transition cursor-pointer select-none ${
                      post.userHearted
                        ? "bg-rose-500/10 text-rose-300 border-rose-500/40"
                        : "bg-[#1B1F27]/60 border-white/5 text-zinc-400 hover:text-zinc-200"
                    }`}
                  >
                    <Heart className={`w-3.5 h-3.5 ${post.userHearted ? "text-rose-400 fill-current" : ""}`} />
                    <span>{post.heartsCount} Sending Love</span>
                  </button>

                </div>
              </div>

            </div>
          ))}
        </div>
      </div>

    </div>
  );
}
