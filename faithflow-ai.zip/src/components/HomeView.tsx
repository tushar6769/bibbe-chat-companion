/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { BookOpen, Play, Calendar, Star, Wind, Compass, ChevronRight, User } from "lucide-react";
import { Devotional } from "../types";
import { motion, AnimatePresence } from "motion/react";

interface HomeViewProps {
  devotional: Devotional;
  onRefreshDevotional: (theme: string, focus: string) => void;
  streakCount: number;
}

export default function HomeView({ devotional, onRefreshDevotional, streakCount }: HomeViewProps) {
  const [isMeditating, setIsMeditating] = useState(false);
  const [breatheStage, setBreatheStage] = useState<"In" | "Hold" | "Out">("In");
  const [breatheSeconds, setBreatheSeconds] = useState(4);
  const [expandedDevotional, setExpandedDevotional] = useState(false);
  const [selectedTheme, setSelectedTheme] = useState("Peace & Sanctuary");

  const themes = [
    { label: "Peace", focus: "finding quiet calm in a busy world" },
    { label: "Strength", focus: "overcoming daily heavy exhaustion or doubt" },
    { label: "Covenant", focus: "experiencing God's promise & constant protection" },
    { label: "Gratitude", focus: "noticing mysterious unearned blessings" },
  ];

  // Simulated rhythmic breathing states
  useEffect(() => {
    if (!isMeditating) return;

    let timer: NodeJS.Timeout;
    const runBreathingCycle = () => {
      setBreatheStage("In");
      setBreatheSeconds(4);

      timer = setTimeout(() => {
        setBreatheStage("Hold");
        setBreatheSeconds(4);

        timer = setTimeout(() => {
          setBreatheStage("Out");
          setBreatheSeconds(4);

          timer = setTimeout(runBreathingCycle, 4000);
        }, 4000);
      }, 4000);
    };

    runBreathingCycle();
    return () => clearTimeout(timer);
  }, [isMeditating]);

  // Breathing timer countdown
  useEffect(() => {
    if (!isMeditating) return;
    const interval = setInterval(() => {
      setBreatheSeconds((prev) => (prev > 1 ? prev - 1 : 4));
    }, 1000);
    return () => clearInterval(interval);
  }, [isMeditating, breatheStage]);

  return (
    <div className="flex-1 flex flex-col gap-6 pt-4 text-warm-beige">
      
      {/* Dynamic Serene Header */}
      <div className="flex items-center justify-between pb-2">
        <div>
          <h2 className="text-3xl font-cinzel text-accent-gold font-bold leading-tight tracking-wider">FaithFlow</h2>
          <p className="text-[11px] font-sans text-zinc-400 tracking-wider font-medium uppercase mt-0.5">Your sanctuary companion</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-full bg-zinc-900 border border-white/5 flex items-center justify-center p-1 cursor-pointer hover:border-accent-gold/40 transition">
            <User className="w-4 h-4 text-accent-gold" />
          </div>
        </div>
      </div>

      {/* Breathing Sanctuary widget - Headspace level feature */}
      <div className="rounded-3xl glassmorphism p-5 flex flex-col gap-4 relative overflow-hidden border border-white/5 select-none shrink-0 cinematic-glow">
        <div className="absolute top-0 right-0 w-24 h-24 bg-accent-gold/5 rounded-full filter blur-xl" />
        
        <div className="flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
            <Wind className="w-5 h-5 text-accent-gold animate-pulse" />
            <h3 className="text-xs font-semibold tracking-wider font-sans text-zinc-300 uppercase">Mental Sanctuary</h3>
          </div>
          <span className="text-[10px] font-mono text-[#D4A75D] bg-[#D4A75D]/10 px-2.5 py-0.5 rounded-full border border-accent-gold/20 font-bold">
            {isMeditating ? "ACTIVE BREATH" : "IDLE COOLDOWN"}
          </span>
        </div>

        <div className="flex items-center gap-4 z-10 py-1.5">
          <div className="relative w-16 h-16 rounded-full flex items-center justify-center bg-[#1B1F27]/80 border border-white/5 shadow-inner">
            {isMeditating ? (
              <motion.div
                animate={{
                  scale: breatheStage === "In" ? [1, 1.45] : breatheStage === "Hold" ? 1.45 : [1.45, 1],
                }}
                transition={{ duration: 4, ease: "easeInOut" }}
                className="absolute inset-1.5 bg-[#D4A75D]/20 rounded-full blur-sm"
              />
            ) : null}
            <button
              onClick={() => setIsMeditating(!isMeditating)}
              className="w-12 h-12 rounded-full bg-gradient-to-tr from-[#D4A75D] to-amber-200 border border-[#D4A75D] flex items-center justify-center text-[#0F1115] hover:scale-105 active:scale-95 transition shadow-lg shrink-0 cursor-pointer"
            >
              <Play className="w-5 h-5 fill-current" />
            </button>
          </div>
          <div>
            <h4 className="text-sm font-sans font-semibold text-zinc-200">
              {isMeditating ? `Breathe ${breatheStage} (${breatheSeconds}s)` : "Diaphragmatic Breathing"}
            </h4>
            <p className="text-[11px] text-zinc-400 mt-0.5 leading-normal">
              {isMeditating
                ? "Match your lungs to the golden glowing ring rhythm."
                : "A gentle 4-4-4 cycle to lower vagal tension and welcome Holy quiet."}
            </p>
          </div>
        </div>
      </div>

      {/* Verse of the Day with Custom Serif Display Typography */}
      <div className="text-center py-6 px-4 bg-gradient-to-b from-[#1B1F27]/30 to-[#1B1F27]/10 rounded-2xl border border-white/5 relative">
        <span className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 text-[9px] font-cinzel text-accent-gold font-bold px-3 py-1 bg-[#1B1F27] rounded-full border border-[#D4A75D]/25 uppercase tracking-widest">
          Sovereign Bread
        </span>
        <blockquote className="font-serif text-lg italic text-[#F5F1E8] mb-3 leading-relaxed font-light px-2">
          "For I know the plans I have for you, declares the Lord, plans for welfare and not for evil, to give you a future and a hope."
        </blockquote>
        <cite className="font-cinzel text-xs text-accent-gold font-bold tracking-widest block not-italic">
          — Jeremiah 29:11
        </cite>
      </div>

      {/* Daily Devotional Hero Card */}
      <div className="rounded-3xl glassmorphism p-6 flex flex-col gap-4 relative overflow-hidden border border-white/5 cinematic-glow">
        <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-[#D4A75D] to-transparent" />
        
        {/* Row 1 */}
        <div className="flex justify-between items-center z-10">
          <div className="flex items-center gap-1.5 text-accent-gold font-semibold text-xs tracking-wider">
            <Calendar className="w-4 h-4" />
            <span className="font-cinzel uppercase">Today's Sanctuary</span>
          </div>
          <span className="text-[10px] text-zinc-400 flex items-center gap-1">
            <BookOpen className="w-3.5 h-3.5 text-accent-gold" />
            5 min read
          </span>
        </div>

        {/* Title */}
        <h3 className="font-serif text-2xl font-semibold leading-tight text-[#F5F1E8] z-10 pr-4">
          {devotional.title}
        </h3>

        {/* Verse Highlight */}
        <div className="bg-[#1B1F27]/60 rounded-xl p-3 border-l-2 border-[#D4A75D] z-10">
          <p className="text-xs text-zinc-300 italic mb-1">"{devotional.verse}"</p>
          <span className="text-[10px] font-cinzel text-accent-gold font-bold">{devotional.reference}</span>
        </div>

        {/* Reflection text with expansion */}
        <div className={`overflow-hidden transition-all duration-300 ${expandedDevotional ? "max-h-[600px]" : "max-h-24"} relative z-10`}>
          <p className="text-xs text-zinc-400 whitespace-pre-line leading-relaxed">
            {devotional.reflection}
          </p>
          <p className="text-xs text-[#F5F1E8] font-serif border-t border-zinc-800/60 pt-3 mt-3 italic text-center">
            {devotional.prayer}
          </p>
          {!expandedDevotional && (
            <div className="absolute bottom-0 left-0 right-0 h-14 bg-gradient-to-t from-[#1B1F27]/96 to-transparent pointer-events-none" />
          )}
        </div>

        {/* Button Controls */}
        <div className="flex items-center justify-between z-10 pt-2 border-t border-zinc-800/50">
          <button
            onClick={() => setExpandedDevotional(!expandedDevotional)}
            className="text-xs font-semibold text-accent-gold hover:text-zinc-300 transition-colors uppercase tracking-wider flex items-center gap-1 cursor-pointer"
          >
            {expandedDevotional ? "Hide Details" : "Read Reflection"}
            <ChevronRight className={`w-3.5 h-3.5 transform transition-transform ${expandedDevotional ? "rotate-90" : ""}`} />
          </button>
        </div>

        {/* Creator Tools Row (AI Generation) */}
        <div className="mt-2 bg-[#1B1F27]/50 p-3 rounded-2xl border border-white/5 z-10">
          <p className="text-[10px] uppercase font-sans tracking-wide text-zinc-400 mb-2">Personalize Spiritual Guidance</p>
          <div className="flex flex-wrap gap-1.5 mb-2.5">
            {themes.map((t) => (
              <button
                key={t.label}
                onClick={() => setSelectedTheme(t.label)}
                className={`text-[10px] px-2.5 py-1 rounded-full border transition cursor-pointer ${
                  selectedTheme === t.label
                    ? "bg-[#D4A75D] text-[#0F1115] border-[#D4A75D] font-bold"
                    : "bg-[#1B1F27] text-zinc-400 border-white/5 hover:text-zinc-200"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>
          <button
            onClick={() => {
              const matched = themes.find((x) => x.label === selectedTheme);
              onRefreshDevotional(selectedTheme, matched ? matched.focus : "");
            }}
            className="w-full text-center py-2 bg-gradient-to-r from-amber-600/20 via-[#D4A75D]/10 to-amber-600/20 hover:from-amber-600/30 hover:to-amber-600/30 border border-[#D4A75D]/30 rounded-xl text-xs font-bold text-accent-gold cursor-pointer transition shadow-[#D4A75D]/5 flex items-center justify-center gap-1.5"
          >
            <Star className="w-3.5 h-3.5 fill-current animate-pulse text-accent-gold" />
            Synthesize Custom Guidance AI
          </button>
        </div>
      </div>

      {/* Continue Reading Section */}
      <div className="flex flex-col gap-3">
        <div className="flex justify-between items-center">
          <h4 className="text-xs font-semibold tracking-wider font-sans uppercase text-zinc-300">Continue Reading</h4>
          <span className="text-[10px] font-semibold text-accent-gold font-cinzel">View Canonical Plans</span>
        </div>

        <div className="grid grid-cols-2 gap-3.5 pb-4">
          <div className="p-4 rounded-2xl glassmorphism hover:border-accent-gold/20 transition cursor-pointer relative group overflow-hidden">
            <div className="absolute top-0 right-0 w-16 h-16 bg-blue-500/5 rounded-full filter blur-md" />
            <span className="text-[9px] font-sans text-zinc-500 block mb-1">GOSPEL PLAN</span>
            <h5 className="font-serif text-sm font-semibold text-zinc-200 leading-snug group-hover:text-accent-gold transition-colors">Romans: Sovereign Grace</h5>
            <div className="flex items-center justify-between mt-3 text-[10px] text-zinc-400 pt-2 border-t border-zinc-800/40">
              <span>Chapter 8</span>
              <span className="text-zinc-500">65% Done</span>
            </div>
          </div>

          <div className="p-4 rounded-2xl glassmorphism hover:border-accent-gold/20 transition cursor-pointer relative group overflow-hidden">
            <div className="absolute top-0 right-0 w-16 h-16 bg-purple-500/5 rounded-full filter blur-md" />
            <span className="text-[9px] font-sans text-zinc-500 block mb-1">PSALMS PLAN</span>
            <h5 className="font-serif text-sm font-semibold text-zinc-200 leading-snug group-hover:text-accent-gold transition-colors">Psalms of Rest & Shelter</h5>
            <div className="flex items-center justify-between mt-3 text-[10px] text-zinc-400 pt-2 border-t border-zinc-800/40">
              <span>Psalm 91</span>
              <span className="text-zinc-500">42% Done</span>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
