/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Wifi, Battery, Signal, Shield, Moon, Compass, Sparkles } from "lucide-react";

interface PhoneMockupProps {
  children: React.ReactNode;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  streakCount: number;
}

export default function PhoneMockup({ children, activeTab, setActiveTab, streakCount }: PhoneMockupProps) {
  const [time, setTime] = useState("");

  useEffect(() => {
    // Elegant, live clock representing premium look but adapted to simulated environment
    const updateTime = () => {
      const now = new Date();
      let hours = now.getHours();
      const minutes = now.getMinutes().toString().padStart(2, "0");
      const ampm = hours >= 12 ? "PM" : "AM";
      hours = hours % 12 || 12;
      setTime(`${hours}:${minutes} ${ampm}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 60000);
    return () => clearInterval(interval);
  }, []);

  const tabs = [
    { id: "home", label: "Sanctuary", icon: Compass },
    { id: "chat", label: "Scribe AI", icon: Sparkles },
    { id: "journal", label: "Journal", icon: Moon },
    { id: "community", label: "Wall", icon: Shield },
    { id: "streaks", label: "Journey", icon: Battery },
  ];

  return (
    <div className="w-full max-w-[430px] h-[880px] bg-[#0F1115] rounded-[52px] p-3.5 relative shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] border-[3px] border-[#1E222A] ring-1 ring-[#D4A75D]/15 flex flex-col overflow-hidden cinematic-glow select-none">
      
      {/* Speaker Bar & Camera Hole (Dynamic Island simulation) */}
      <div className="absolute top-5 left-1/2 -translate-x-1/2 w-[110px] h-[30px] bg-black rounded-full flex items-center justify-between px-3.5 z-50 border border-white/5">
        <div className="w-1.5 h-1.5 bg-zinc-800 rounded-full" />
        <div className="w-14 h-2.5 bg-zinc-900 rounded-full border border-white/5 shadow-inner" />
        <div className="w-2.5 h-2.5 bg-[#4c1d95]/40 rounded-full border border-blue-500/20 shadow-[0_0_5px_rgba(59,130,246,0.5)]" />
      </div>

      {/* Screen Header Row */}
      <div className="flex justify-between items-center px-6 pt-3 pb-2 text-[11px] font-sans text-zinc-400 font-medium z-40 bg-[#0F1115]/40 backdrop-blur-md">
        <span className="text-[12px] font-semibold text-zinc-300 select-none">{time || "12:00 PM"}</span>
        <div className="flex items-center gap-1.5">
          <div className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/25">
            <span className="text-[9px] font-cinzel text-accent-gold font-bold">🔥 {streakCount} Days</span>
          </div>
          <Signal className="w-3.5 h-3.5 text-zinc-300" />
          <Wifi className="w-3.5 h-3.5 text-zinc-300" />
          <Battery className="w-4 h-4 text-zinc-300" />
        </div>
      </div>

      {/* App Body Content Viewport */}
      <div className="flex-1 flex flex-col overflow-y-auto px-4 pb-20 relative scrollbar-none">
        {children}
      </div>

      {/* Bottom Floating Navigation bar with beautiful glowing cues */}
      <div className="absolute bottom-4 left-4 right-4 h-18 glassmorphism rounded-3xl flex items-center justify-around px-2 z-40 shadow-[0_10px_30px_rgba(0,0,0,0.5)] border border-white/10">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className="flex flex-col items-center justify-center w-14 h-14 rounded-2xl relative transition-all duration-300 cursor-pointer"
            >
              {isActive && (
                <div className="absolute inset-0 bg-[#D4A75D]/10 rounded-2xl border border-[#D4A75D]/25 shadow-[inset_0_0_8px_rgba(212,167,93,0.1)]" />
              )}
              
              <Icon
                className={`w-5 h-5 transition-transform duration-300 ${
                  isActive ? "text-[#D4A75D] scale-110 drop-shadow-[0_0_8px_rgba(212,167,93,0.4)]" : "text-zinc-500 hover:text-zinc-300"
                }`}
              />
              <span
                className={`text-[9px] mt-1 tracking-wide font-sans ${
                  isActive ? "text-warm-beige font-semibold" : "text-zinc-500"
                }`}
              >
                {tab.label}
              </span>

              {isActive && (
                <span className="absolute bottom-1 w-1.5 h-1.5 bg-[#D4A75D] rounded-full shadow-[0_0_10px_rgba(212,167,93,0.8)]" />
              )}
            </button>
          );
        })}
      </div>

      {/* iPhone Home Indicator Line */}
      <div className="absolute bottom-1 left-1/2 -translate-x-1/2 w-32 h-1 bg-zinc-650 rounded-full opacity-60 z-50 pointer-events-none" />
    </div>
  );
}
