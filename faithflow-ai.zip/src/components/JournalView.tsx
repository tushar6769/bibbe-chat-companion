/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { BookOpen, Calendar, ChevronRight, PenTool, Plus, Volume2, Smile, AlertCircle, Info, Trash2, Heart } from "lucide-react";
import { JournalEntry, MoodType, JournalPrompt } from "../types";
import { GUIDED_PROMPTS } from "../data";

interface JournalViewProps {
  entries: JournalEntry[];
  onAddEntry: (mood: MoodType, promptText: string, entryText: string) => void;
  onDeleteEntry: (id: string) => void;
  onSynthesizeSpeech: (id: string, text: string) => void;
  playingAudioId: string | null;
  isSynthesizing: boolean;
}

export default function JournalView({
  entries,
  onAddEntry,
  onDeleteEntry,
  onSynthesizeSpeech,
  playingAudioId,
  isSynthesizing,
}: JournalViewProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [activeMood, setActiveMood] = useState<MoodType>("Peaceful");
  const [selectedPrompt, setSelectedPrompt] = useState<JournalPrompt>(GUIDED_PROMPTS[0]);
  const [entryText, setEntryText] = useState("");

  const moods: { type: MoodType; emoji: string }[] = [
    { type: "Peaceful", emoji: "😌" },
    { type: "Anxious", emoji: "🥺" },
    { type: "Doubtful", emoji: "🌪️" },
    { type: "Grateful", emoji: "🙌" },
    { type: "Weary", emoji: "😴" },
    { type: "Hopeful", emoji: "✨" },
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!entryText.trim()) return;
    onAddEntry(activeMood, selectedPrompt.text, entryText.trim());
    setEntryText("");
    setIsAdding(false);
  };

  const handleRandomPrompt = () => {
    const unselected = GUIDED_PROMPTS.filter((p) => p.id !== selectedPrompt.id);
    const random = unselected[Math.floor(Math.random() * unselected.length)];
    setSelectedPrompt(random);
  };

  return (
    <div className="flex-1 flex flex-col gap-6 pt-4 text-warm-beige select-none">
      
      {/* View Header */}
      <div className="flex items-center justify-between">
        <div>
          <span className="text-[10px] uppercase font-sans tracking-widest text-[#D4A75D] font-bold bg-[#D4A75D]/10 px-2.5 py-1 rounded-full border border-accent-gold/20">
            Prayer Diary
          </span>
          <h2 className="text-2xl font-serif font-bold text-[#F5F1E8] mt-2">Personal Sanctuary</h2>
        </div>
        {!isAdding && (
          <button
            onClick={() => setIsAdding(true)}
            className="w-10 h-10 rounded-full bg-[#D4A75D] hover:bg-amber-400 text-[#0F1115] flex items-center justify-center cursor-pointer hover:scale-105 active:scale-95 transition shadow-lg shadow-amber-500/10"
          >
            <Plus className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Guided Journal Form Card */}
      {isAdding ? (
        <form onSubmit={handleSave} className="rounded-3xl glassmorphism p-5 flex flex-col gap-4 border border-[#D4A75D]/20 cinematic-glow relative">
          <div className="absolute top-0 right-12 w-20 h-20 bg-[#D4A75D]/5 rounded-full filter blur-lg" />
          
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-mono text-zinc-400 flex items-center gap-1.5 uppercase font-semibold">
              <PenTool className="w-3.5 h-3.5 text-accent-gold" />
              Guided Prompt
            </span>
            <button
              type="button"
              onClick={() => setIsAdding(false)}
              className="text-xs text-zinc-400 hover:text-zinc-200 uppercase cursor-pointer"
            >
              Cancel
            </button>
          </div>

          {/* Random Prompt Roller */}
          <div className="bg-[#1B1F27]/80 rounded-2xl p-4 border border-white/5 flex flex-col gap-2">
            <p className="text-xs text-zinc-300 italic font-sans leading-relaxed">
              "{selectedPrompt.text}"
            </p>
            <div className="flex justify-between items-center pt-2.5 border-t border-zinc-800/60 mt-1">
              <span className="text-[10px] font-semibold text-accent-gold uppercase tracking-wider bg-[#D4A75D]/10 px-2.5 py-0.5 rounded-full">
                {selectedPrompt.category}
              </span>
              <button
                type="button"
                onClick={handleRandomPrompt}
                className="text-[10px] font-cinzel text-amber-300 flex items-center gap-1 hover:text-accent-gold font-bold uppercase tracking-wider cursor-pointer"
              >
                Next prompt <ChevronRight className="w-3 h-3" />
              </button>
            </div>
          </div>

          {/* State mood picker */}
          <div className="flex flex-col gap-1.5">
            <span className="text-[10px] uppercase tracking-wider text-zinc-400 font-semibold flex items-center gap-1">
              <Smile className="w-3.5 h-3.5 text-accent-gold" />
              Present Soul Weather
            </span>
            <div className="grid grid-cols-3 gap-2">
              {moods.map((m) => (
                <button
                  key={m.type}
                  type="button"
                  onClick={() => setActiveMood(m.type)}
                  className={`py-2 px-1 rounded-xl flex flex-col items-center justify-center gap-1 text-[11px] font-sans border transition cursor-pointer select-none ${
                    activeMood === m.type
                      ? "bg-[#D4A75D]/15 text-[#F5F1E8] border-[#D4A75D] shadow-inner"
                      : "bg-[#1B1F27]/50 text-zinc-400 border-white/5 hover:bg-[#1B1F27]"
                  }`}
                >
                  <span className="text-base">{m.emoji}</span>
                  <span className="font-medium">{m.type}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Prompt Entry Box */}
          <div className="flex flex-col gap-1.5">
            <textarea
              value={entryText}
              onChange={(e) => setEntryText(e.target.value)}
              placeholder="Unload your heart, describe your spiritual connection, or express gratitude here..."
              rows={4}
              required
              className="w-full text-xs bg-[#1B1F27] border border-white/10 rounded-2xl p-3.5 focus:outline-none focus:border-[#D4A75D] placeholder-zinc-500 font-sans leading-relaxed text-warm-beige"
            />
          </div>

          <button
            type="submit"
            className="w-full text-center py-3 bg-[#D4A75D] hover:bg-amber-400 text-[#0F1115] rounded-xl font-bold text-xs uppercase tracking-widest transition cursor-pointer"
          >
            Seale In Memory
          </button>
        </form>
      ) : null}

      {/* Diary logs list */}
      <div className="flex flex-col gap-4">
        <h3 className="text-xs font-semibold tracking-wider uppercase text-zinc-300 font-sans px-1">Preserved Entries</h3>
        
        {entries.length === 0 ? (
          <div className="text-center py-10 px-4 bg-[#1B1F27]/30 rounded-3xl border border-white/5">
            <BookOpen className="w-8 h-8 text-zinc-600 mx-auto mb-2.5" />
            <p className="text-xs text-zinc-400 font-medium">Your sanctuary diary is currently quiet.</p>
            <p className="text-[11px] text-zinc-500 mt-1 max-w-[220px] mx-auto">Create a secure reflection using one of our peaceful prompts to ground your today.</p>
          </div>
        ) : (
          <div className="space-y-4 max-h-[480px] overflow-y-auto pr-1 pb-4">
            {entries.map((entry) => {
              const matchedMood = moods.find((m) => m.type === entry.mood);
              const isPlaying = playingAudioId === entry.id;

              return (
                <div
                  key={entry.id}
                  className="rounded-2xl glassmorphism p-5 border border-white/5 hover:border-zinc-800/80 transition flex flex-col gap-3 relative Group"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{matchedMood?.emoji || "😌"}</span>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-[#F5F1E8] font-sans">{entry.mood}</span>
                          <span className="text-[6px] text-zinc-500">•</span>
                          <span className="text-[9px] font-mono text-zinc-400 flex items-center gap-1">
                            <Calendar className="w-3 h-3 text-[#D4A75D]" /> {entry.date}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => onSynthesizeSpeech(entry.id, entry.entryText)}
                        disabled={isSynthesizing && !isPlaying}
                        className={`w-7 h-7 rounded-lg flex items-center justify-center border transition cursor-pointer ${
                          isPlaying
                            ? "bg-[#D4A75D]/10 border-[#D4A75D] text-accent-gold"
                            : "bg-[#1B1F27]/60 border-white/5 text-zinc-400 hover:text-zinc-200"
                        }`}
                        title="Read entry with serene voice synthesis"
                      >
                        <Volume2 className={`w-3.5 h-3.5 ${isPlaying ? "animate-pulse" : ""}`} />
                      </button>
                      
                      <button
                        onClick={() => onDeleteEntry(entry.id)}
                        className="w-7 h-7 rounded-lg flex items-center justify-center bg-red-950/20 border border-red-500/10 text-red-400/80 hover:text-red-300 transition cursor-pointer hover:bg-red-950/40"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Prompt Text Reference */}
                  <p className="text-[10px] font-sans text-[#D4A75D] font-semibold bg-[#D4A75D]/5 px-2.5 py-1 rounded-lg border border-[#D4A75D]/10">
                    Prompt: "{entry.promptText}"
                  </p>

                  <p className="text-xs text-zinc-300 leading-relaxed font-sans whitespace-pre-line bg-zinc-950/25 p-3 rounded-xl border border-white/5">
                    {entry.entryText}
                  </p>

                  {isPlaying && (
                    <div className="flex items-center gap-2 bg-[#D4A75D]/5 p-2 rounded-xl border border-[#D4A75D]/20 animate-pulse text-[10px] text-accent-gold font-mono">
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>Synthesized seraphic voice playing live prayer stream...</span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

    </div>
  );
}
