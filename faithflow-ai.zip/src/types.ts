/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Devotional {
  verse: string;
  reference: string;
  title: string;
  reflection: string;
  prayer: string;
  isFallback?: boolean;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

export type MoodType = "Peaceful" | "Anxious" | "Doubtful" | "Grateful" | "Weary" | "Hopeful";

export interface JournalPrompt {
  id: string;
  text: string;
  category: string;
}

export interface JournalEntry {
  id: string;
  date: string;
  mood: MoodType;
  promptText: string;
  entryText: string;
  audioKey?: string; // If synthesized to TTS audio
  isAudioPlaying?: boolean;
}

export interface PrayerPost {
  id: string;
  author: string;
  isAnonymous: boolean;
  content: string;
  category: "Praise" | "Healing" | "Comfort" | "Anxiety" | "Strength" | "Guidance";
  prayersCount: number;
  heartsCount: number;
  userPrayed: boolean;
  userHearted: boolean;
  timestamp: string; // e.g. "2 hours ago"
}

export interface StreakBadge {
  id: string;
  title: string;
  description: string;
  unlocked: boolean;
  iconName: string;
  unlockedAt?: string;
}

export interface HabitTask {
  id: string;
  title: string;
  timeOfDay: "Morning" | "Afternoon" | "Evening";
  completed: boolean;
}

export interface WeeklyActivity {
  day: string; // e.g., "Mon", "Tue"
  minutes: number;
  completed: boolean;
}
