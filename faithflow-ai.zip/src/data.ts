/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Devotional, JournalPrompt, JournalEntry, PrayerPost, StreakBadge, HabitTask, WeeklyActivity } from "./types";

export const INITIAL_DEVOTIONAL: Devotional = {
  title: "The Sanctuary of Quiet Waters",
  verse: "The Lord is my shepherd; I shall not want. He makes me lie down in green pastures. He leads me beside still waters. He restores my soul.",
  reference: "Psalm 23:1-3",
  reflection: "In a world calibrated to constant movement and noisy notification chimes, stepping into stillness can feel counter-cultural. Yet, God does not speak in the roaring wind or the earthquake; He comes to us in the sound of sheer silence. Resting beside 'still waters' is an active realignment of the heart, allowing the silt of earthly anxiety to settle so the reflection of His face becomes clear again.\n\nWhen we pause to breathe, we are not wasting time; we are reclaiming it. Christ himself regularly retreated to quiet mountainsides to model this restorative rhythm.\n\nToday, let go of the pressure to self-produce your security. Trust that the Shepherd has already laid out green pastures of grace that are sufficient for this hour.",
  prayer: "Lord, lead me away from the rush of my internal demands. Restore my soul beside Your quiet waters, and help me walk with a light, trustful step today. Amen."
};

export const GUIDED_PROMPTS: JournalPrompt[] = [
  { id: "p1", text: "What specific burden or worry are you carrying today? Hold it in prayer and write it out, surrendering it to larger hands.", category: "Relaxation" },
  { id: "p2", text: "Look closely at the past 24 hours. Name three unexpected moments where grace or unearned kindness met you.", category: "Gratitude" },
  { id: "p3", text: "Who in your immediate circle is currently climbing a difficult mountain? Pen a silent prayer for their strength and victory.", category: "Intercession" },
  { id: "p4", text: "Is there a choice or a word from your past week that still pricks your conscience? Write a confession of forgiveness here.", category: "Forgiveness" },
  { id: "p5", text: "If you could ask the Savior for one specific form of guidance for your current season, what would it be?", category: "Guidance" },
  { id: "p6", text: "Describe a scripture or sacred song that feels like a heavy coat of warm wool shielding you from the cold. Why does it comfort you?", category: "Reflection" }
];

export const INITIAL_JOURNAL_ENTRIES: JournalEntry[] = [
  {
    id: "j1",
    date: "2026-05-26",
    mood: "Grateful",
    promptText: "Name three unexpected moments where grace met you.",
    entryText: "Today I watched the sunrise paint the clouds in rose gold, and I had a deeply comforting conversation with an old friend. I felt a profound sense of companionship and relief from a weight I didn't realize I was bearing. I am learning that quiet gratitude is a shield against daily storms."
  },
  {
    id: "j2",
    date: "2026-05-24",
    mood: "Anxious",
    promptText: "What specific burden are you carrying today?",
    entryText: "I'm feeling heavily overwhelmed by upcoming decisions and career deadlines. It feels like everyone is expecting answers I do not have yet. I'm reminding myself of Matthew 6:34: 'Do not worry about tomorrow, for tomorrow will worry about itself.' Writing this helps me lay down the crown of being in control."
  }
];

export const INITIAL_COMMUNITY_PRAYERS: PrayerPost[] = [
  {
    id: "w1",
    author: "Grace_S",
    isAnonymous: false,
    content: "Please lift up my grandmother in your prayers. She is undergoing physical rehabilitation after a fall, and her spirit is a bit down. Praying for miraculous strength, pain reduction, and a restored sense of joy.",
    category: "Healing",
    prayersCount: 42,
    heartsCount: 18,
    userPrayed: false,
    userHearted: false,
    timestamp: "2 hours ago"
  },
  {
    id: "w2",
    author: "HopefulRest",
    isAnonymous: true,
    content: "Praising God today for an anonymous caller who helped pay off my family's medical debt. It felt like an absolute answer to weeks of persistent prayers. Truly overwhelmed by the secret goodness in people.",
    category: "Praise",
    prayersCount: 89,
    heartsCount: 76,
    userPrayed: true,
    userHearted: true,
    timestamp: "4 hours ago"
  },
  {
    id: "w3",
    author: "Marcus_J",
    isAnonymous: false,
    content: "Going through an intense season of academic exam pressures. Fighting persistent physical and mental exhaustion. I ask for deep mental clarity, steady faith, and the remindful calm that my worth doesn't lie in grades.",
    category: "Strength",
    prayersCount: 21,
    heartsCount: 9,
    userPrayed: false,
    userHearted: false,
    timestamp: "1 day ago"
  },
  {
    id: "w4",
    author: "ComfortPath",
    isAnonymous: true,
    content: "Prayers for any souls who are grappling with the heavy void of grief. Today marks one year since I lost my brother. The waves are smaller now, but the undertow is still real. Keep us in your comfort thoughts.",
    category: "Comfort",
    prayersCount: 65,
    heartsCount: 38,
    userPrayed: false,
    userHearted: false,
    timestamp: "3 days ago"
  }
];

export const STREAK_BADGES: StreakBadge[] = [
  {
    id: "b1",
    title: "Prayer Spark",
    description: "Maintained a steady 3-day quiet companion prayer habit",
    unlocked: true,
    iconName: "Zap",
    unlockedAt: "Yesterday"
  },
  {
    id: "b2",
    title: "Sanctuary Seeker",
    description: "Maintained a divine 7-day devotion reading streak",
    unlocked: true,
    iconName: "Shield",
    unlockedAt: "3 days ago"
  },
  {
    id: "b3",
    title: "Compassionate Soul",
    description: "Prayed for 10 community requests on the Prayer Wall",
    unlocked: false,
    iconName: "HeartHandshake"
  },
  {
    id: "b4",
    title: "Scribe of Grace",
    description: "Logged 5 guided meditations in your Prayer Journal",
    unlocked: false,
    iconName: "PenTool"
  },
  {
    id: "b5",
    title: "Deep Grounded",
    description: "Engaged in theological deep explorations with FaithFlow AI",
    unlocked: false,
    iconName: "BookOpen"
  }
];

export const HABIT_TASKS: HabitTask[] = [
  { id: "h1", title: "Read the Daily Devotional of Sanctuary", timeOfDay: "Morning", completed: true },
  { id: "h2", title: "Brief 5-minute silent reflection with still breathing", timeOfDay: "Morning", completed: true },
  { id: "h3", title: "Quiet journaling exercise of grace or gratitude", timeOfDay: "Afternoon", completed: false },
  { id: "h4", title: "Evening review of spiritual peace & scripture", timeOfDay: "Evening", completed: false }
];

export const WEEKLY_ACTIVITY_DATA: WeeklyActivity[] = [
  { day: "Mon", minutes: 15, completed: true },
  { day: "Tue", minutes: 20, completed: true },
  { day: "Wed", minutes: 10, completed: true },
  { day: "Thu", minutes: 25, completed: true },
  { day: "Fri", minutes: 15, completed: true },
  { day: "Sat", minutes: 30, completed: true },
  { day: "Sun", minutes: 45, completed: true }
];
