/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import PhoneMockup from "./components/PhoneMockup";
import HomeView from "./components/HomeView";
import ChatView from "./components/ChatView";
import JournalView from "./components/JournalView";
import CommunityView from "./components/CommunityView";
import StreaksView from "./components/StreaksView";

import { Devotional, ChatMessage, JournalEntry, PrayerPost, StreakBadge, HabitTask, WeeklyActivity, MoodType } from "./types";
import { INITIAL_DEVOTIONAL, INITIAL_JOURNAL_ENTRIES, INITIAL_COMMUNITY_PRAYERS, STREAK_BADGES, HABIT_TASKS, WEEKLY_ACTIVITY_DATA } from "./data";
import { Sparkles, Info, Settings, ShieldAlert, Check, HelpCircle, Volume2, Globe } from "lucide-react";

export default function App() {
  // Navigation & Interactive States
  const [activeTab, setActiveTab] = useState<string>("home");
  const [streakCount, setStreakCount] = useState<number>(5);

  // App domain states
  const [devotional, setDevotional] = useState<Devotional>(INITIAL_DEVOTIONAL);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([
    {
      id: "welcome",
      role: "assistant",
      content: "Grace be to you. I am your scripture companion, FaithFlow. Ask me anything—whether evaluating Hebrew scripture roots, clarifying Matthew 6, or offering a peaceful comforting blessing for your anxiety.",
      timestamp: new Date(),
    },
  ]);
  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(INITIAL_JOURNAL_ENTRIES);
  const [communityPosts, setCommunityPosts] = useState<PrayerPost[]>(INITIAL_COMMUNITY_PRAYERS);
  const [badges, setBadges] = useState<StreakBadge[]>(STREAK_BADGES);
  const [habits, setHabits] = useState<HabitTask[]>(HABIT_TASKS);
  const [weeklyActivity, setWeeklyActivity] = useState<WeeklyActivity[]>(WEEKLY_ACTIVITY_DATA);

  // API Call loader states
  const [isLoadingChat, setIsLoadingChat] = useState(false);
  const [isRefreshingDevotional, setIsRefreshingDevotional] = useState(false);
  const [isSynthesizingTTS, setIsSynthesizingTTS] = useState(false);
  const [playingAudioId, setPlayingAudioId] = useState<string | null>(null);

  // HTML Audio node reference to stream synthesized TTS voice
  const [audioNode, setAudioNode] = useState<HTMLAudioElement | null>(null);

  // 1. CHAT MESSAGE HANDLER (Gemini API /api/chat)
  const handleSendMessage = async (text: string) => {
    // Append client message
    const userMessage: ChatMessage = {
      id: Math.random().toString(),
      role: "user",
      content: text,
      timestamp: new Date(),
    };

    const newHistory = [...chatHistory, userMessage];
    setChatHistory(newHistory);
    setIsLoadingChat(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: newHistory }),
      });

      if (!response.ok) {
        throw new Error("Sanctuary servers temporarily in silent reflection.");
      }

      const data = await response.json();
      const assistantMsg: ChatMessage = {
        id: Math.random().toString(),
        role: "assistant",
        content: data.text,
        timestamp: new Date(),
      };
      setChatHistory((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      console.error("Chat reflection error:", err);
      // Friendly in-app fallback error message
      setChatHistory((prev) => [
        ...prev,
        {
          id: Math.random().toString(),
          role: "assistant",
          content: "I am having difficulty connecting our direct prayer line right now. Please test again in a brief second.",
          timestamp: new Date(),
        },
      ]);
    } finally {
      setIsLoadingChat(false);
    }
  };

  // 2. DEVOTIONAL SYNTHESIS HANDLER (Gemini API /api/devotional)
  const handleRefreshDevotional = async (theme: string, focus: string) => {
    setIsRefreshingDevotional(true);
    try {
      const response = await fetch("/api/devotional", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ theme, focus }),
      });

      if (!response.ok) {
        throw new Error("Unable to receive updated holy thoughts.");
      }

      const data = await response.json();
      if (data.verse) {
        setDevotional(data);
      }
    } catch (err) {
      console.error("Devotional synthesis failure:", err);
    } finally {
      setIsRefreshingDevotional(false);
    }
  };

  // 3. SECURE TEXT TO SPEECH REQUISITION (Gemini TTS API)
  const handleSynthesizeSpeech = async (entryId: string, text: string) => {
    // If already playing this, toggle pause
    if (playingAudioId === entryId) {
      if (audioNode) {
        audioNode.pause();
        audioNode.currentTime = 0;
      }
      setPlayingAudioId(null);
      return;
    }

    // Stop any other running audio
    if (audioNode) {
      audioNode.pause();
    }

    setIsSynthesizingTTS(true);
    try {
      const response = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, voice: "Kore" }),
      });

      const data = await response.json();
      if (data.base64Audio) {
        const audioSrc = `data:audio/mp3;base64,${data.base64Audio}`;
        const newAudio = new Audio(audioSrc);
        
        newAudio.onended = () => {
          setPlayingAudioId(null);
        };
        newAudio.play();
        setAudioNode(newAudio);
        setPlayingAudioId(entryId);
      } else {
        alert(data.error || "Serene speech synthesis requires a live GEMINI_API_KEY configured in Secrets.");
      }
    } catch (err: any) {
      console.error("TTS generation went wrong:", err);
      alert("Spiritual voice synthesis encountered a temporary network delay.");
    } finally {
      setIsSynthesizingTTS(false);
    }
  };

  // 4. JOURNAL OPERATION HANDLERS
  const handleAddJournalEntry = (mood: MoodType, promptText: string, entryText: string) => {
    const newEntry: JournalEntry = {
      id: "j_" + Math.random().toString(),
      date: new Date().toISOString().split("T")[0],
      mood,
      promptText,
      entryText,
    };
    setJournalEntries([newEntry, ...journalEntries]);

    // Check if scribing opens "Scribe of Grace" badge!
    const count = journalEntries.length + 1;
    if (count >= 3) {
      setBadges((prev) =>
        prev.map((b) => (b.id === "b4" ? { ...b, unlocked: true, unlockedAt: "Just Now" } : b))
      );
    }
  };

  const handleDeleteJournalEntry = (id: string) => {
    setJournalEntries((prev) => prev.filter((e) => e.id !== id));
  };

  // 5. COMMUNITY POST OPERATION HANDLERS
  const handleAddCommunityPost = (content: string, isAnonymous: boolean, category: any) => {
    const newPost: PrayerPost = {
      id: "w_" + Math.random().toString(),
      author: isAnonymous ? "Anonymous" : "Tushar_K",
      isAnonymous,
      content,
      category,
      prayersCount: 0,
      heartsCount: 0,
      userPrayed: false,
      userHearted: false,
      timestamp: "Just Now",
    };
    setCommunityPosts([newPost, ...communityPosts]);
  };

  const handleReactPost = (id: string, type: "pray" | "heart") => {
    setCommunityPosts((prev) =>
      prev.map((post) => {
        if (post.id === id) {
          if (type === "pray") {
            const added = !post.userPrayed;
            return {
              ...post,
              userPrayed: added,
              prayersCount: added ? post.prayersCount + 1 : post.prayersCount - 1,
            };
          } else {
            const added = !post.userHearted;
            return {
              ...post,
              userHearted: added,
              heartsCount: added ? post.heartsCount + 1 : post.heartsCount - 1,
            };
          }
        }
        return post;
      })
    );

    // Double-check 'Compassionate Soul' badge criteria
    setBadges((prev) =>
      prev.map((b) => (b.id === "b3" ? { ...b, unlocked: true, unlockedAt: "Just Now" } : b))
    );
  };

  // 6. PROGRESS HABIT ROUTINES
  const handleToggleHabit = (id: string) => {
    setHabits((prev) =>
      prev.map((h) => (h.id === id ? { ...h, completed: !h.completed } : h))
    );

    // Update streak minutes dynamically
    setWeeklyActivity((prev) =>
      prev.map((dayData, idx) => (idx === prev.length - 1 ? { ...dayData, minutes: dayData.minutes + 5 } : dayData))
    );
  };

  return (
    <div className="min-h-screen bg-[#0F1115] flex flex-col items-center justify-center p-4 md:p-8 relative selection:bg-[#D4A75D] selection:text-[#0F1115]">
      
      {/* Background elegant atmospheric particles/shadow */}
      <div className="absolute top-[10%] left-[15%] w-96 h-96 rounded-full bg-amber-500/[0.03] filter blur-[120px] pointer-events-none" />
      <div className="absolute bottom-[20%] right-[10%] w-[450px] h-[450px] rounded-full bg-violet-500/[0.03] filter blur-[150px] pointer-events-none" />

      {/* Main interactive grid framing */}
      <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-[#15181E]/40 border border-white/5 rounded-[40px] p-6 lg:p-10 relative z-10 glassmorphism shadow-2xl">
        
        {/* Left Side: Editorial Introduction & Companion Manual */}
        <div className="lg:col-span-7 flex flex-col gap-6" id="welcome_section">
          
          <div className="flex items-center gap-2.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-pulse" />
            <span className="text-[10px] tracking-widest text-[#D4A75D] font-cinzel font-black uppercase">
              APPLE DESIGN AWARDEE SELECTION MOCKUP
            </span>
          </div>

          <div className="flex items-baseline gap-2.5 mt-1">
            <h1 className="text-4xl md:text-5xl font-cinzel font-bold text-warm-beige tracking-tight leading-tight">
              FaithFlow<span className="text-transparent bg-clip-text bg-gradient-to-tr from-[#D4A75D] to-amber-200"> AI</span>
            </h1>
          </div>

          <p className="text-sm text-zinc-400 leading-relaxed font-sans font-light">
            An emotionally calming, premium faith companion bridging biblical sanctuary with Gemini's modern theological intelligence. Beautifully styled using deep dark cinematic slate (#0F1115) paired with rich shimmering gold highlights.
          </p>

          {/* AI Info details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 my-2">
            
            <div className="p-4 rounded-2xl bg-[#1B1F27]/60 border border-white/5 flex gap-3">
              <div className="p-2 bg-[#D4A75D]/10 rounded-xl h-10 w-10 flex items-center justify-center border border-[#D4A75D]/20 shrink-0">
                <Sparkles className="w-4 h-4 text-accent-gold" />
              </div>
              <div className="flex flex-col">
                <h4 className="text-xs font-bold text-[#F5F1E8]">Sovereign AI Scribe</h4>
                <p className="text-[11px] text-zinc-400 leading-normal mt-0.5">Custom scriptural insights, Hebrew roots research, and responsive empathetic guides.</p>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-[#1B1F27]/60 border border-white/5 flex gap-3">
              <div className="p-2 bg-[#D4A75D]/10 rounded-xl h-10 w-10 flex items-center justify-center border border-[#D4A75D]/20 shrink-0">
                <Volume2 className="w-4 h-4 text-accent-gold" />
              </div>
              <div className="flex flex-col">
                <h4 className="text-xs font-bold text-[#F5F1E8]">Seraphic Voice Synthesis</h4>
                <p className="text-[11px] text-zinc-400 leading-normal mt-0.5">Synthesize personal prayer reflections into highly calm voice streams using Gemini SDK.</p>
              </div>
            </div>

          </div>

          {/* Configuration Secrets Panel Guidelines */}
          <div className="p-5 rounded-2xl bg-amber-500/[0.04] border border-[#D4A75D]/15 flex flex-col gap-2 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-1 h-full bg-[#D4A75D]" />
            <div className="flex items-center gap-2 text-xs font-bold text-accent-gold">
              <Info className="w-4 h-4" />
              <span className="font-cinzel tracking-wider uppercase">Spiritual Integration Dashboard</span>
            </div>
            <p className="text-xs text-zinc-300 leading-relaxed font-sans">
              <strong>FaithFlow AI</strong> is fully configured to fetch actual scriptural responses, draft daily devotionals, and read journal entries with physical voices. To unlock active generation, click the <strong>Secrets Panel</strong> in the Google AI Studio menu and authorize:
            </p>
            <div className="mt-2 text-[11px] bg-black/40 p-2.5 rounded-xl border border-white/5 space-y-1 font-mono text-zinc-400">
              <div className="flex items-center justify-between">
                <span>🔑 GEMINI_API_KEY</span>
                <span className="text-amber-300 font-semibold font-sans">Auto-detected at runtime</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-zinc-500 mt-2 font-mono">
            <Globe className="w-3.5 h-3.5 text-accent-gold" />
            <span>Serving over secure Cloud Run container • Port 3000 mapped</span>
          </div>

        </div>

        {/* Right Side: The Premium Mobile Mockup Canvas */}
        <div className="lg:col-span-5 flex justify-center w-full" id="mockup_container">
          
          <PhoneMockup activeTab={activeTab} setActiveTab={setActiveTab} streakCount={streakCount}>
            
            {activeTab === "home" && (
              <HomeView
                devotional={devotional}
                onRefreshDevotional={handleRefreshDevotional}
                streakCount={streakCount}
              />
            )}

            {activeTab === "chat" && (
              <ChatView
                chatHistory={chatHistory}
                onSendMessage={handleSendMessage}
                isLoading={isLoadingChat}
              />
            )}

            {activeTab === "journal" && (
              <JournalView
                entries={journalEntries}
                onAddEntry={handleAddJournalEntry}
                onDeleteEntry={handleDeleteJournalEntry}
                onSynthesizeSpeech={handleSynthesizeSpeech}
                playingAudioId={playingAudioId}
                isSynthesizing={isSynthesizingTTS}
              />
            )}

            {activeTab === "community" && (
              <CommunityView
                posts={communityPosts}
                onAddPost={handleAddCommunityPost}
                onReactPost={handleReactPost}
              />
            )}

            {activeTab === "streaks" && (
              <StreaksView
                streakCount={streakCount}
                badges={badges}
                habits={habits}
                weeklyActivity={weeklyActivity}
                onToggleHabit={handleToggleHabit}
              />
            )}

          </PhoneMockup>

        </div>

      </div>

    </div>
  );
}
